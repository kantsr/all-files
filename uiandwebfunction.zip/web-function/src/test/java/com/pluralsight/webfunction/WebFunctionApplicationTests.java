package com.pluralsight.webfunction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebFunctionApplicationTests {

	@Test
	void contextLoads() {
	}

}
